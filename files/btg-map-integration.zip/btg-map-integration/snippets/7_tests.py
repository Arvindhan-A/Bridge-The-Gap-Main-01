# ================================================================
# 7) TESTS  —  tests/test_chapters_map.py
# ----------------------------------------------------------------
# Mirrors the existing integration-test style. Adjust fixture names
# (client, super_admin_client, db_session, make_chapter) to match
# whatever your conftest.py already provides.
# ================================================================

import json
import pytest


def test_map_page_public(client):
    """Anyone can view the map page."""
    resp = client.get("/chapters/map")
    assert resp.status_code == 200
    assert b"bdg-map" in resp.data


def test_geo_feed_only_returns_placed_chapters(client, db_session, make_chapter):
    placed   = make_chapter(name="Chennai", slug="chennai", latitude=13.08, longitude=80.27)
    unplaced = make_chapter(name="Nowhere", slug="nowhere", latitude=None, longitude=None)
    db_session.commit()

    resp = client.get("/api/chapters/geo")
    assert resp.status_code == 200
    data = resp.get_json()["chapters"]
    names = {c["name"] for c in data}

    assert "Chennai" in names
    assert "Nowhere" not in names
    # shape check
    chennai = next(c for c in data if c["name"] == "Chennai")
    assert set(chennai.keys()) == {"id", "name", "president", "url", "lat", "lng"}
    assert chennai["lat"] == 13.08 and chennai["lng"] == 80.27


def test_set_coordinates_requires_auth(client, make_chapter, db_session):
    """Anonymous users cannot write coordinates."""
    ch = make_chapter(name="Chennai", slug="chennai")
    db_session.commit()
    resp = client.post(
        f"/chapters/{ch.id}/coordinates",
        data=json.dumps({"latitude": 13.0, "longitude": 80.0}),
        content_type="application/json",
    )
    assert resp.status_code in (302, 401, 403)  # redirect to login or forbidden


def test_set_coordinates_rejects_wrong_role(president_client, make_chapter, db_session):
    """A chapter president (non-super-admin) cannot use the super-admin endpoint."""
    ch = make_chapter(name="Chennai", slug="chennai")
    db_session.commit()
    resp = president_client.post(
        f"/chapters/{ch.id}/coordinates",
        data=json.dumps({"latitude": 13.0, "longitude": 80.0}),
        content_type="application/json",
    )
    assert resp.status_code in (302, 403)


def test_set_coordinates_success(super_admin_client, make_chapter, db_session):
    ch = make_chapter(name="Chennai", slug="chennai")
    db_session.commit()
    resp = super_admin_client.post(
        f"/chapters/{ch.id}/coordinates",
        data=json.dumps({"latitude": 13.0827, "longitude": 80.2707}),
        content_type="application/json",
        headers={"X-CSRFToken": _csrf(super_admin_client)},
    )
    assert resp.status_code == 200
    db_session.refresh(ch)
    assert round(ch.latitude, 4) == 13.0827


def test_clear_coordinates(super_admin_client, make_chapter, db_session):
    ch = make_chapter(name="Chennai", slug="chennai", latitude=13.0, longitude=80.0)
    db_session.commit()
    resp = super_admin_client.post(
        f"/chapters/{ch.id}/coordinates",
        data=json.dumps({"latitude": None, "longitude": None}),
        content_type="application/json",
        headers={"X-CSRFToken": _csrf(super_admin_client)},
    )
    assert resp.status_code == 200
    db_session.refresh(ch)
    assert ch.latitude is None and ch.longitude is None


def test_set_coordinates_rejects_missing_csrf(super_admin_client, make_chapter, db_session):
    """With CSRF enabled, a POST without the token is rejected."""
    ch = make_chapter(name="Chennai", slug="chennai")
    db_session.commit()
    resp = super_admin_client.post(
        f"/chapters/{ch.id}/coordinates",
        data=json.dumps({"latitude": 13.0, "longitude": 80.0}),
        content_type="application/json",
        # no X-CSRFToken header
    )
    assert resp.status_code in (400, 403)


# --- helper ---------------------------------------------------------------
def _csrf(client):
    """Pull a CSRF token from any rendered form page.
    Adapt the page/regex to your app. If tests disable CSRF globally,
    delete the csrf tests and the headers above.
    """
    import re
    html = client.get("/chapters/map").get_data(as_text=True)
    m = re.search(r'name="csrf-token" content="([^"]+)"', html)
    return m.group(1) if m else ""
