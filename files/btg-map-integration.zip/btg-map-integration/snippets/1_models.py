# ================================================================
# 1) MODEL  —  btg/models.py
# ----------------------------------------------------------------
# Add these two columns to your existing `Chapter` model.
# (slug, name, and president are assumed to already exist — if
#  president lives on a related User/Team record instead, see the
#  note in the route file for how to resolve it.)
# ================================================================

class Chapter(db.Model):
    # ... your existing columns ...

    latitude  = db.Column(db.Float, nullable=True)
    longitude = db.Column(db.Float, nullable=True)

    @property
    def has_pin(self):
        return self.latitude is not None and self.longitude is not None
