# ================================================================
# 6) VENDORED ASSETS + CSP
# ================================================================
#
# The map needs three third-party files. For a production Flask app
# behind a Content-Security-Policy, serving them locally is cleaner
# than allowing an external CDN. Download these into static/vendor/:
#
#   static/vendor/d3.v7.min.js
#       https://cdn.jsdelivr.net/npm/d3@7/dist/d3.min.js
#
#   static/vendor/topojson-client.v3.min.js
#       https://cdn.jsdelivr.net/npm/topojson-client@3/dist/topojson-client.min.js
#
#   static/vendor/countries-110m.json
#       https://cdn.jsdelivr.net/npm/world-atlas@2/countries-110m.json
#
# Quick fetch (run from your project root):
#
#   mkdir -p static/vendor
#   curl -L -o static/vendor/d3.v7.min.js \
#        https://cdn.jsdelivr.net/npm/d3@7/dist/d3.min.js
#   curl -L -o static/vendor/topojson-client.v3.min.js \
#        https://cdn.jsdelivr.net/npm/topojson-client@3/dist/topojson-client.min.js
#   curl -L -o static/vendor/countries-110m.json \
#        https://cdn.jsdelivr.net/npm/world-atlas@2/countries-110m.json
#
# The map template already points at these local paths via url_for.
#
# ----------------------------------------------------------------
# IF YOU PREFER THE CDN INSTEAD (no vendoring):
# ----------------------------------------------------------------
# In templates/chapters/map.html, replace the two vendored <script>
# tags with:
#   <script src="https://cdn.jsdelivr.net/npm/d3@7/dist/d3.min.js"></script>
#   <script src="https://cdn.jsdelivr.net/npm/topojson-client@3/dist/topojson-client.min.js"></script>
# and set window.BDG_MAP.worldUrl to the jsDelivr countries-110m.json URL.
#
# Then your CSP must allow jsdelivr for BOTH script and connect (the
# world JSON is fetched via XHR, so it needs connect-src, not just
# script-src):
#
#   Content-Security-Policy:
#     script-src 'self' https://cdn.jsdelivr.net;
#     connect-src 'self' https://cdn.jsdelivr.net;
#
# Vendoring locally avoids needing to touch CSP at all — everything
# stays on 'self'.
#
# ----------------------------------------------------------------
# INLINE SCRIPT NOTE
# ----------------------------------------------------------------
# map.html has one small inline <script> that sets window.BDG_MAP.
# If your CSP forbids inline scripts ('unsafe-inline' not allowed and
# no nonce), either:
#   (a) add a nonce: <script nonce="{{ csp_nonce() }}"> and include the
#       same nonce in your CSP header, OR
#   (b) move the window.BDG_MAP assignment into data-* attributes on
#       #bdg-map and read them in chapters-map.js.
# Most setups allow a nonce most easily.
